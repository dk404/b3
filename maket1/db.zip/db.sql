-- --------------------------------------------------------
-- Сервер:                       127.0.0.1
-- Версія сервера:               5.7.11 - MySQL Community Server (GPL)
-- ОС сервера:                   Win64
-- HeidiSQL Версія:              9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for таблиця maketdatabase.confirmemail
CREATE TABLE IF NOT EXISTS `confirmemail` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `email` varchar(250) NOT NULL DEFAULT '0',
  `token` varchar(250) NOT NULL DEFAULT '0',
  `status` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- Dumping data for table maketdatabase.confirmemail: ~0 rows (приблизно)
/*!40000 ALTER TABLE `confirmemail` DISABLE KEYS */;
INSERT IGNORE INTO `confirmemail` (`ID`, `email`, `token`, `status`) VALUES
	(4, 'Petya@mail.ru', '0177bba222d88d7e685f07997e019cd0', 0),
	(6, 'Admin@mail.ru', '6330f51f47681ae98c5d05e372c55910', 0);
/*!40000 ALTER TABLE `confirmemail` ENABLE KEYS */;


-- Dumping structure for таблиця maketdatabase.users
CREATE TABLE IF NOT EXISTS `users` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `email` varchar(250) NOT NULL DEFAULT '0',
  `pass` varchar(250) NOT NULL DEFAULT '0',
  `token` varchar(250) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Dumping data for table maketdatabase.users: ~0 rows (приблизно)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT IGNORE INTO `users` (`ID`, `email`, `pass`, `token`) VALUES
	(3, 'Petya@mail.ru', '$2y$10$nWcNiUp8PfXw7IlRUbb2P.OqCxo7dNKYsybBo2B4p.dEAuCkzBCya', '0'),
	(4, 'Admin@mail.ru', '$2y$10$9Mwt0VZpE3hkcegPfWkJhudl/tZdmCQ3Bzj.DZiiaUG9cknbXDQWW', '0');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
